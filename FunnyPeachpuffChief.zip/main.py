  
import requests
import json

def query_github():
    
    url = "https://api.github.com/users/ghivert/repos"
    response = requests.get(url)
    data = response.json()

         
    path = '/ghivert.json' 
    data = datadef(path)



 
    for dict in data:
        print(dict["name"])
        print(dict["description"])

      
def datadef(path):
    file = open(path)
    content = file.read()
    file.close()
    return json.loads(content)



query_github()
